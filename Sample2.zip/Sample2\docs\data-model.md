# Roadmap Data Model

## Design goals

SQLite is the authoritative store for roadmap content. The schema must support
an arbitrary number of phases and an arbitrary number of details per phase.
Avoid schema designs that require a migration when a user adds a phase or a
detail.

## `roadmap_phases`

Recommended columns:

| Column | Type | Rules |
|---|---|---|
| `id` | integer or UUID | Primary key |
| `title` | text | Required, bounded length |
| `goal` | text | Required, bounded length |
| `description` | text | Required or explicitly nullable |
| `dependency` | text | Nullable |
| `scope` | text | Nullable |
| `delivery_criteria` | text | Nullable |
| `status` | text | One of the domain status values |
| `team_note` | text | Nullable |
| `sort_order` | integer | Required, unique within the roadmap |
| `priority` | integer or derived rank | User-controlled priority/order; must be normalized and persisted |
| `created_at` | timestamp | Required |
| `updated_at` | timestamp | Required |

Create an index on `(sort_order)` and an index on `(status, sort_order)`.
If the product supports multiple roadmaps or tenants, add a parent identifier
and scope uniqueness/indexes by that identifier.

## `roadmap_details`

Recommended columns:

| Column | Type | Rules |
|---|---|---|
| `id` | integer or UUID | Primary key |
| `phase_id` | integer or UUID | Foreign key to `roadmap_phases` |
| `content` | text | Required, bounded length |
| `sort_order` | integer | Required within its phase |
| `created_at` | timestamp | Required |
| `updated_at` | timestamp | Required |

Use a foreign key with the chosen deletion policy. Add an index on
`(phase_id, sort_order)`. The preferred policy is cascading deletion inside the
same transaction after explicit user confirmation.

## Domain rules

- Status is validated against one centralized enum or equivalent definition.
- Sort order is normalized after inserts, deletes, and moves.
- `updated_at` changes on every successful content, status, note, or ordering
  mutation.
- Seed data is inserted only when the relevant database is empty.
- Reads always order phases by `sort_order` and details by their phase-local
  `sort_order`.
- A reorder mutation must be atomic, normalize all affected positions, update
  timestamps, and remain correct after application restart.
- `sort_order` is the persistence representation of the user-visible priority;
  the UI must also provide keyboard-accessible alternatives to drag-and-drop.

## Statistics

The service may calculate statistics from one aggregate query or a small set of
queries. It must return at least:

```text
total
unset
notStarted
started
done
completionPercent
```

When `total` is zero, `completionPercent` must be `0`, not `NaN` or an error.

