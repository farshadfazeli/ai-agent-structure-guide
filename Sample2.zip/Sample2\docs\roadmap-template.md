# Generic Roadmap Template Requirements

This document defines the next product direction. It is intentionally
business-agnostic: a later request will provide the business description, and
the application will turn it into persisted, editable roadmap content.

## Template behavior

The dashboard must work with zero, one, or any number of phases. A phase has
editable title, goal, description, dependencies, scope, delivery criteria,
status, team note, priority, and development details. Details are independent
records owned by a phase and have their own editable order.

The user can create a phase through a prominent, polished creation surface;
edit every field; add, edit, delete, and reorder details; reorder phases; and
see all successful changes immediately. Drag-and-drop is a convenience, not the
only interaction: keyboard move-before/move-after controls are required.

## Ordering contract

Phase priority and detail order are persisted values, not browser-only state.
Every move is validated for ownership and identifier correctness, performed in
an atomic transaction, normalized to contiguous positions, and reflected in
the dashboard without a full reload. Reloading or restarting the application
must produce the same order.

## Visual direction

Use the supplied reference only as a structural cue. The new template should
have its own visual identity and should not be a pixel copy. Keep the useful
information hierarchy—hero, dynamic summary, filters, roadmap content,
details, and print view—but use a distinct modern layout and a strong
new-phase creation experience.

Persian/RTL typography is a first-class requirement. Define a deliberate font
stack with a Persian-capable primary or fallback font, test mixed Persian and
Latin text, use readable line-height and weights, and avoid mojibake caused by
incorrect source or response encoding.

## Content policy

No business name, industry, phase title, fixed phase count, or business detail
from an earlier request is a requirement for this template. Seed data may be
minimal demonstration content only, must be removable, and must never be
embedded in rendering logic. The database remains the sole source of truth.
