# Acceptance Checklist

## Data and persistence

- [ ] A fresh run creates the configured SQLite database.
- [ ] Migrations can run repeatedly without failure or duplicate schema.
- [ ] Seed data is inserted only when appropriate and is fully editable.
- [ ] Restarting the application preserves every successful mutation.
- [ ] Browser storage is not used as the authoritative data source.

## Dynamic behavior

- [ ] The UI renders every phase returned by the database.
- [ ] Adding a phase changes the total immediately.
- [ ] Deleting a phase changes totals, status counts, and progress immediately.
- [ ] The progress denominator is the current number of phases.
- [ ] Zero phases produce a valid empty state and 0% progress.
- [ ] Status filters operate on current data without deleting hidden records.
- [ ] Reordering phases and details survives a restart.
- [ ] The application is business-agnostic and does not require a fixed seed
      business, title set, or number of phases.
- [ ] A new phase has a polished, accessible creation experience.
- [ ] Phase priority can be changed by drag-and-drop and by keyboard controls.
- [ ] Development details can be dragged to reorder within their phase.
- [ ] Both reorder operations persist immediately and remain correct after
      reload and restart.

## Editing

- [ ] Every phase field can be edited through a controlled UI.
- [ ] Details can be created, edited, deleted, and reordered.
- [ ] Notes persist and show their latest update time.
- [ ] Invalid input is rejected with a useful message.
- [ ] Destructive operations require confirmation.

## Reliability and security

- [ ] SQL queries are parameterized.
- [ ] Multi-record mutations use transactions.
- [ ] User text is escaped and never executed as markup.
- [ ] Missing records and database failures produce safe, understandable errors.
- [ ] Import files are size-limited, schema-validated, and rejected safely.
- [ ] Automated tests cover CRUD, ordering, status statistics, and persistence.

## Experience

- [ ] The interface is usable on mobile and desktop.
- [ ] Critical controls are keyboard accessible.
- [ ] Loading, empty, success, and error states are visible.
- [ ] Print/PDF output hides editing controls and remains readable.
- [ ] Setup and operational instructions are documented in the project README.
- [ ] The visual language is distinct from the supplied reference while
      preserving a clear roadmap structure.
- [ ] Persian text uses a tested font stack with correct glyph rendering,
      readable line height, and responsive RTL layout.
- [ ] New-phase creation, drag handles, and move controls are keyboard and
      screen-reader accessible.

