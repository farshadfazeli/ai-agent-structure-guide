# Systan Business Roadmap — ASP.NET Core MVC Development Instructions

## Objective

Build a production-ready, fully dynamic business-roadmap dashboard. The product
partitions the work of a business into editable phases and development details.
The visual target is the supplied Systan roadmap reference: a green hero,
dynamic summary cards, a readable phase table, filters, notes, and print view.
The implementation technology is mandatory: ASP.NET Core MVC on .NET 8.
Use Controllers, Razor Views, ViewModels, application services, repositories,
and SQLite through Entity Framework Core. Do not implement the application as
the existing Node.js server or as a static-only HTML page. Razor views may use
separate `.cshtml`, CSS, and JavaScript assets under the normal ASP.NET Core
MVC structure.
When a user describes a business, the agent must analyze the business itself,
propose a sensible ordered set of phases, dependencies, goals, scope, delivery
criteria, and development details, then create those phase records in the
database. The user must not be required to manually add the initial phases.
Generated phases are ordinary editable records: every field and detail must be
editable, and successful edits must be persisted immediately.
The application must treat the database as the only source of truth. The user
interface must be generated from persisted records and must never depend on a
hard-coded number of phases, fixed phase names, or browser-only storage.

## Mandatory technology and architecture

- Target framework: `net8.0` with ASP.NET Core MVC.
- Use Razor Views for presentation and strongly typed ViewModels for requests
  and responses. Do not put SQL, business rules, or persistence code in views.
- Use Controllers only for HTTP orchestration; put business operations in an
  application/service layer and database access in repository/data-access code.
- Use EF Core SQLite with migrations, configurable connection string, foreign
  keys, indexes, and transactions for multi-record mutations.
- Use built-in dependency injection, configuration, logging, antiforgery
  validation, model binding, and server-side validation.
- Keep domain statuses centralized in a domain model or enum-like definition.
- Use `dotnet test` for automated tests, preferably with an isolated SQLite
  test database for integration coverage.
- The agent must create or update the `.csproj`, `Program.cs`, MVC folders,
  migrations, seed layer, views, assets, tests, README, and launch settings as
  needed for a runnable .NET 8 MVC project.
- Do not introduce Node.js, Express, a separate Node API, React, or browser
  storage as an alternative application architecture.

The implementation should support the complete lifecycle of roadmap content:
create, read, update, delete, reorder, filter, import, and export. A fresh
installation may include seed data, but seed data is only initial content and
must remain completely editable and removable.

## Non-negotiable principles

1. **Database-driven UI**: all phases, fields, development details, statuses,
   ordering values, notes, and timestamps must be loaded from SQLite through the
   application data layer.
2. **No hard-coded phase count**: totals, status cards, progress percentages,
   table rows, navigation, and empty states must be derived from query results.
3. **No hard-coded roadmap content**: phase titles and descriptions are seed
   values only. They must not be embedded in rendering logic.
4. **Single source of truth**: `localStorage`, session storage, static JSON, or
   HTML-embedded state may be used only for non-authoritative UI preferences.
5. **Immediate persistence**: a successful edit must be persisted without a full
   page reload, then reflected in all affected UI components.
6. **Safe mutations**: validate input at the boundary, use parameterized SQL,
   use transactions for multi-record changes, and return actionable errors.
7. **Preserve existing work**: do not remove unrelated code or configuration.

## Functional scope

### Dynamic roadmap phases

Each phase must support the following editable fields:

- title
- goal
- description
- dependency information
- scope
- delivery or acceptance criteria
- status
- team note
- priority/order
- development-detail items

Users must be able to create a phase, view it, edit every field, delete it with
confirmation, change its status, and reorder it. Deleting a phase must apply an
explicit dependent-record policy, preferably a transaction with cascading
deletion of its development details after confirmation.

### Development details

Development details are independent records belonging to a phase. The user must
be able to add, edit, delete, and reorder them without editing raw application
data. Reordering must be persisted and must remain correct after restarting the
application.

### Dashboard and filtering

The dashboard must dynamically render:

- the total number of phases
- one summary count for each supported status
- the completed-phase percentage
- the phase table or card list
- an empty state when no phases exist
- a status filter that does not mutate or lose hidden records

The completed percentage must be calculated as `done / total * 100`, with a safe
zero-total result. The calculation must use current database data, not a fixed
denominator.

The supported status values are:

- `unset` — Unset
- `not-started` — Not started
- `started` — Started
- `done` — Done

Keep these values centralized in one domain definition so labels, validation,
filters, colors, and summary queries cannot drift apart. Additional statuses
must be introduced through the domain model and migration process rather than by
duplicating conditionals throughout the UI.

## User experience requirements

- Use a clear, responsive layout that works on desktop and mobile screens.
- Keep the roadmap readable in English and use semantic, accessible HTML.
- Provide keyboard-accessible forms, dialogs, menus, filters, and reorder
  controls.
- Clearly distinguish loading, empty, saved, validation-error, and server-error
  states.
- Show the last update time for each team note and any other record where it is
  useful.
- Keep destructive actions behind confirmation and explain their consequences.
- Escape user-provided text on output; never interpret roadmap content as HTML.
- Provide a print-friendly view that hides editing controls and remains useful
  when printed or exported to PDF.

The visual theme may use a dark green header and status colors, but styling must
be implemented as reusable design tokens or classes. Do not couple behavior to
literal color values.

## Persistence and data architecture

Use SQLite at a configurable path supplied by application configuration or an
environment variable. The database setup must be idempotent: running the
application repeatedly must not create duplicate tables, duplicate seed rows,
or duplicate details.

Recommended entities and fields are documented in `docs/data-model.md`.
Implement the following boundaries:

- presentation/UI layer
- application/service layer
- repository/data-access layer
- database migration and seed layer

The UI must not issue SQL directly. Repositories must use parameterized
queries, explicit transactions, foreign keys, and indexes appropriate for
phase ordering and detail ordering. Store timestamps consistently and format
them only at the presentation boundary using the configured application time
zone.

## Required operations

Implement and test these operations through the application/service layer:

1. List all phases with their development details in persisted order.
2. Return dynamic status counts and progress statistics.
3. Create, update, and delete phases.
4. Change phase status and team note.
5. Create, update, delete, and reorder development details.
6. Reorder phases.
7. Filter phases by status.
8. Import validated roadmap data.
9. Export current roadmap data in a documented format.

All multi-step operations must be atomic. Reordering must normalize ordering
values so gaps or duplicate positions cannot break rendering.

## Validation and error handling

Validate required fields, maximum lengths, status values, identifiers, order
values, and relationship ownership on both the UI boundary and the server/data
boundary. Return stable error categories that the UI can translate into useful
messages. Handle missing records, malformed import files, invalid status values,
database constraint errors, and concurrent updates without exposing SQL or
stack traces to end users.

## Seed data

On an empty database, create a small initial roadmap covering these logical
areas:

1. Shared infrastructure and data contracts
2. Forms and core operations
3. Lists, views, and live data
4. Component integration, pages, and user experience

These records must be ordinary database rows. The application must work equally
well if the user edits, reorders, adds, or deletes them. Initial statuses should
be `unset`, initial notes should be empty, and initial ordering should be
deterministic.

## Testing and acceptance

Add automated coverage for:

- idempotent migrations and seed behavior
- phase CRUD
- development-detail CRUD
- phase and detail reordering
- status validation and status counts
- zero-phase and zero-progress calculations
- dynamic totals after create/delete operations
- persistence after restart
- import validation and export round trips
- authorization or ownership checks where applicable
- responsive and accessible critical interactions

The implementation is complete only when the acceptance checklist in
`docs/acceptance-checklist.md` passes. Update the project README with setup,
configuration, migration, seed, run, test, and database backup instructions.

## Delivery expectations

Before handing off:

1. Inspect the existing project structure and preserve unrelated changes.
2. Implement the data model and idempotent database initialization.
3. Implement repositories and services before wiring UI mutations.
4. Replace static rendering assumptions with database-driven rendering.
5. Verify that all mutations update the dashboard without a reload.
6. Run the relevant test suite and record any environment limitation clearly.

## Reference UI requirements

The attached reference document `C:\Users\farshad\Desktop\archive\SystanPortal_Development_Roadmap.html` is a visual and naming reference only. Its browser `localStorage` implementation must not replace SQLite as the application source of truth.

The dashboard should follow the reference composition: Persian RTL layout, dark-to-green rounded hero, Systan eyebrow, amber tag, four dynamic status cards, notice panel, action/filter toolbar, responsive roadmap table, expandable development details, inline status/note editing, and print/PDF styling. All roadmap content must still be loaded from persisted database records.

The canonical phase titles are exactly:

1. `تثبیت زیرساخت مشترک و قراردادها`
2. `فرم واقعی و اکشن‌های پایه`
3. `لیست و View با داده واقعی`
4. `اتصال فرم و لیست؛ گرید و اکشن‌های وابسته`
5. `صفحه و Routing`
6. `مسیر مشتری، احراز هویت و مدیریت دسترسی`
7. `تکمیل دامنه اصلی و آمادگی انتشار`
8. `امکانات کم‌اولویت‌تر، داخل اسکوپ`

These titles are ordinary editable database values. They must not be hard-coded in Razor rendering logic, summary calculations, or client-side authoritative state. If the reference and a user request conflict, the latest explicit user request controls the product content; the reference controls only the requested visual language and canonical title spelling.

## Current product direction: business-agnostic roadmap template

The previous business-specific seed content and canonical title list are obsolete for the next product iteration. Do not preserve or introduce a fixed business, portal, industry, company, or phase-title set. The next implementation must be a reusable roadmap template that can receive a business description later and generate/edit persisted phases from that description.

The template must support:

- creating a new phase from a polished, modern, visually distinct creation experience;
- an arbitrary number of editable phases with no hard-coded names or count;
- changing phase priority by drag-and-drop and accessible move controls, with the new order persisted immediately;
- dragging development-detail items to change their order, with phase ownership and order persisted immediately;
- adding, editing, and deleting phases and development details;
- dynamic summary, filtering, empty states, and progress derived from persisted records;
- correct Persian/RTL typography with an intentional font stack, readable weights, spacing, and fallback fonts that render Persian glyphs correctly;
- a UI that is clearly differentiated from the attached reference while retaining its useful roadmap structure (hero, summary, filters, roadmap content, details, and print view).

The reference HTML is inspiration for structure only. Its business content, fixed eight-phase list, browser storage, and visual styles must not be copied as authoritative product requirements. Business-specific phases and details will be supplied in a later request and must be generated as ordinary editable database records.

## Implementation notes

- Development-detail creation validates the persisted `phase_id` relationship and returns a safe error instead of exposing an exception.
- Phase and development-detail reordering uses temporary negative positions inside an EF Core transaction before writing contiguous positions, preventing SQLite unique-index collisions.
- Phase editing loads the record through `/roadmap/phases/{id}` and does not serialize EF navigation graphs into HTML attributes.
- When dependencies are already restored, run with `dotnet run --no-restore --no-launch-profile --urls http://localhost:5299`; the dashboard is available at `/roadmap`.

